# GitHub Pages Setup Guide
### nahuruiz.com → your portfolio hub

---

## What you need before starting
- A GitHub account (free) → github.com
- Your `index.html` file (already done)
- Your images folder ready (optional, can add later)
- Access to your domain's DNS settings (wherever you bought nahuruiz.com — GoDaddy, Namecheap, etc.)

---

## STEP 1 — Create a GitHub account

1. Go to **github.com** and click **Sign up**
2. Pick a username — this will be part of your default URL so something like `nahuruiz` is ideal
3. Verify your email and log in

---

## STEP 2 — Create your repository

A "repository" (repo) is just a folder on GitHub that holds your site files.

1. Click the **+** icon (top right) → **New repository**
2. Name it exactly: `nahuruiz.github.io`
   - This special name tells GitHub to treat it as a website
   - If your username is different, use `YOURUSERNAME.github.io`
3. Set it to **Public** (required for free GitHub Pages)
4. Check **Add a README file**
5. Click **Create repository**

---

## STEP 3 — Upload your files

1. Inside your new repo, click **Add file → Upload files**
2. Drag in your `index.html`
3. If you have images, create an `images/` folder by uploading a file named `images/anything.jpg` — GitHub will auto-create the folder
4. Scroll down, write a short message like "Initial upload" and click **Commit changes**

Your site is now live at: `https://nahuruiz.github.io`

> Give it 1–2 minutes the first time, then open that URL to check it works.

---

## STEP 4 — Enable GitHub Pages (confirm it's on)

1. In your repo, click **Settings** (top tab)
2. Scroll down to **Pages** in the left sidebar
3. Under **Source**, make sure it says **Deploy from a branch**
4. Branch should be set to **main** / **(root)**
5. Click **Save** if you changed anything

---

## STEP 5 — Connect your custom domain (nahuruiz.com)

### In GitHub:
1. Go to **Settings → Pages**
2. Under **Custom domain**, type: `nahuruiz.com`
3. Click **Save**
4. GitHub will create a file called `CNAME` in your repo — leave it alone

### In your domain registrar (GoDaddy / Namecheap / etc.):
Go to your domain's **DNS settings** and add these records:

**A Records** (point your root domain to GitHub):
```
Type    Host    Value               TTL
A       @       185.199.108.153     Auto
A       @       185.199.109.153     Auto
A       @       185.199.110.153     Auto
A       @       185.199.111.153     Auto
```

**CNAME Record** (optional, for www redirect):
```
Type    Host    Value                       TTL
CNAME   www     nahuruiz.github.io          Auto
```

> DNS changes take anywhere from 10 minutes to 24 hours to fully propagate. Be patient.

### Back in GitHub:
Once DNS propagates, go back to **Settings → Pages** and check the **Enforce HTTPS** box. This gives you the green padlock on your site.

---

## STEP 6 — How to update your site going forward

Updating is simple — no command line needed:

### To swap an image or update text:
1. Go to your repo on github.com
2. Click on `index.html`
3. Click the **pencil icon** (Edit this file)
4. Make your changes
5. Click **Commit changes** at the bottom
6. Wait ~30 seconds, then refresh your site

### To add new images:
1. Go to your repo
2. Click **Add file → Upload files**
3. Drag your new images into the `images/` folder path
4. Commit

---

## STEP 7 — What to edit in your index.html

Open the file and search for these markers (`Ctrl+F` or `Cmd+F`):

| What to find | What to change |
|---|---|
| `YOUR_USERNAME` | Your ArtStation/social handles |
| `hello@nahuruiz.com` | Your actual email |
| `ALBUM_ID` | Your ArtStation collection IDs (from the URL when viewing a collection) |
| `@yourhandle` | Your actual social handles |
| `<!-- EDIT: write your own bio here -->` | Your bio text |
| `<!-- REPLACE with: <img src=...` | Uncomment and point to your images |
| `SPAIN` | Your city/location |
| `Available for freelance` | Change if you're not open to work |

---

## Tips

- **Image naming**: keep filenames lowercase with no spaces. Use `-` instead: `warrior-character.jpg` not `Warrior Character.jpg`
- **Image sizing**: keep images under 500KB each for fast loading. Use squoosh.app (free, browser-based) to compress
- **Backup**: GitHub IS your backup. Every version you commit is saved. You can roll back anytime
- **NDA PDF**: Host your password-protected PDF on Google Drive (already your setup) and link to it privately — do NOT upload the PDF to your public GitHub repo

---

## If something breaks

- **Site not loading**: Wait 10 min, hard refresh (`Ctrl+Shift+R`)
- **Images not showing**: Check the path exactly matches — `images/myfile.jpg` is case-sensitive on GitHub
- **Domain not working**: DNS is still propagating — check again in a few hours
- **Need to undo a change**: In your repo, click **History** on any file to see old versions

---

*That's it. Once this is set up, day-to-day maintenance is just uploading images and editing one HTML file.*
